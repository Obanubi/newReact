import { Component, useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import Ralph from './Person'

const App =() =>{
    return(
        <>
          <Ralph oruko= "RaphaelKing">A Chelsea Fan</Ralph>
          <Ralph oruko="Tobiloba"></Ralph>
          <Ralph oruko="Footballer"> A chelsea player</Ralph>
          <Ralph oruko= "Cole Palmer">Better Than Saka </Ralph>
        </>
      
    )
}

// class App extends Component{
//   render(){
//     return(
//       <>
//          <Ralph oruko="Ademola">my surname</Ralph>
//          <Ralph oruko="Footballer"> A chelsea player</Ralph>
//           <Ralph oruko= "Cole Palmer"> </Ralph>
//       </>
//     )
//   }
// }
export default App

