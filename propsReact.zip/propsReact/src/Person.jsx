const Person = (props) => {
    return(
        <>
        <h1>WELCOME😁...</h1>
        <h2>Hi, i am {props.oruko} and i am {Math.floor(Math.random()*100)} </h2>

        <p>{props.children}</p>
       <hr />
         </>
         
    )
}
export default Person;